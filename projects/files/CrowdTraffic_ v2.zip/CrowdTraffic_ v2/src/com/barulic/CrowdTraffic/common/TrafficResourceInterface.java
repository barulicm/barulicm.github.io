package com.barulic.CrowdTraffic.common;

import java.util.ArrayList;

import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.Put;

public interface TrafficResourceInterface {

	
	@Post
	public ArrayList<TrafficRecord> getRecords(GeoRegion inRegion);
	
	@Put
	public void storeRecord(TrafficRecord record);
	
	@Delete
	public void clearRecords();
	
	@Get
	public ArrayList<TrafficRecord> getAllRecords();
}
