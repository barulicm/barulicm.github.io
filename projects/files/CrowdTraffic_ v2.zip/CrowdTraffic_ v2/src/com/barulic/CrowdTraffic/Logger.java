package com.barulic.CrowdTraffic;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

/**
 * This class manages writing messages to the log file in the correct, human-readable format.
 * 
 * @author Matt Barulic
 *
 */
public class Logger {

	private Activity _host;
	private final String filename = "Crowd_Traffic_Log_File";
	private FileOutputStream file;
	private SharedPreferences settings;
	private boolean isOpen = false;
	
	public Logger(Activity host) {
		_host = host;
		settings = CrowdTrafficController.settings;
	}
	
	public void startLogging(){
		try {
			file = _host.openFileOutput(filename, Context.MODE_APPEND);
			isOpen = true;
		} catch (Exception e) {
			Toast.makeText(_host, "Error opening log file.", Toast.LENGTH_LONG).show();
		}
	}
	
	public void LogMessage(Object sender, String message){
		try {
			if(!settings.getBoolean("log", false))return;
			if(!isOpen)return;
			Date d = new Date();
			d.setTime(System.currentTimeMillis());
			SimpleDateFormat format = new SimpleDateFormat("MMM dd HH:mm:ss");
			String log = "- " + format.format(d) + " " +sender.getClass().getSimpleName() + " : " + message + "\n";
			file.write(log.getBytes());
		} catch (Exception e) {
			Toast.makeText(_host, "Error writing to log file.", Toast.LENGTH_LONG);
		}
	}
	
	public void endLogging(){
		try {
			file.close();
			isOpen = false;
		} catch (Exception e) {
			Toast.makeText(_host, "Error closing log file.", Toast.LENGTH_LONG);
		}
	}

}
