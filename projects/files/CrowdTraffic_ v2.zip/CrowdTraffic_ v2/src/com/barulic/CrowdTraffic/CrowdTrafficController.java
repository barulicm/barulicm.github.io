package com.barulic.CrowdTraffic;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.Toast;

import com.barulic.CrowdTraffic.common.TrafficRecord;

/**
 * Root activity of the application
 * @author Matt Barulic
 *
 */
public class CrowdTrafficController extends TabActivity implements LocationMonitorHost {
	
	public static TrafficDatabase db;
	private LocationMonitor locMonitor;
	public static SharedPreferences settings;
	private Location prevLoc;
	private TrafficRecord prevRecord;
	private Geocoder geocoder;
	public static TabHost tabHost;
	private static ConnectivityManager connMan = null;
	private AlertDialog alert;
	private boolean networkTypeAlertShown = false;
	private boolean networkConnectionAlertShown = false;
	private boolean gpsAlertShown = false;
	private boolean showGPSalert;
	
	private static boolean wasOnline = true;
	
	public static int prevTab = 0;
	
	public static Logger logger;
	public static boolean connectedToInternet;
	
	private static boolean firstClose = true;
	
	public static Activity rootActivity;
	
	public static Handler uiHandler;

	/**
	 * Called when the activity is initialized.
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		rootActivity = this;
		uiHandler = new Handler();
		
		setContentView(R.layout.main);
		
        connMan = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
		
		//Setup User speed prefs
        settings = getPreferences(MODE_PRIVATE);
        if(!settings.contains("lowSpeed") || 
        		!settings.contains("upSpeed") || 
        		!settings.contains("log") || 
        		!settings.contains("buffer") ||
        		!settings.contains("archiveHour") ||
        		!settings.contains("archiveDay") ||
        		!settings.contains("useNetwork")){
        	SharedPreferences.Editor editor = settings.edit();
        	editor.putInt("lowSpeed", 10);
        	editor.putInt("upSpeed", 35);
        	editor.putBoolean("log", false);
        	editor.putBoolean("buffer", false);
        	editor.putInt("archiveHour", 0);
        	editor.putInt("archiveDay", 0);
        	editor.putBoolean("useNetwork", true);
        	editor.commit();
        }
        
        connectedToInternet = isOnline();

    	logger = new Logger(this);
    	logger.startLogging();
    	logger.LogMessage(this, "Starting app...");

        db = new TrafficDatabase(this);
        locMonitor = new LocationMonitor(this);
        locMonitor.startWatchingLocation();
        geocoder = new Geocoder(this);
		
		tabHost = getTabHost();
        TabHost.TabSpec spec;
        Intent intent;
        
        intent = new Intent().setClass(this, LiveMapController.class);
        spec = tabHost.newTabSpec("live").setIndicator("Live Map", null).setContent(intent);
        tabHost.addTab(spec);
        
        intent = new Intent().setClass(this, ArchivedMapController.class);
        spec = tabHost.newTabSpec("archived").setIndicator("Archive", null).setContent(intent);
        tabHost.addTab(spec);	
        
        intent = new Intent().setClass(this, SettingsPanelController.class);
        spec = tabHost.newTabSpec("settings").setIndicator("Settings", null).setContent(intent);
        tabHost.addTab(spec);
        
        intent = new Intent().setClass(this, LogViewerController.class);
        spec = tabHost.newTabSpec("log").setIndicator("Log", null).setContent(intent);
        tabHost.addTab(spec);
        
        tabHost.setOnTabChangedListener(new OnTabChangeListener(){
			public void onTabChanged(String tabId) {
				if(tabId.equals("live")){
					setTitle("Crowd Traffic - Live Map");
				} else if(tabId.equals("archived")){
					setTitle("Crowd Traffic - Archived Map");
				} else if(tabId.equals("settings")){
					setTitle("Crowd Traffic - Settings");
				} else if(tabId.equals("log")){
					setTitle("Crowd Traffic - Log");
				}
			}});
        tabHost.setCurrentTab(0);
		
		setTitle("Crowd Traffic - Live Map");
        
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
        alert = builder.create();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		if(!db.isConnectedLive()) db.connectLive(this);
		if(!db.isConnectedArchive()) db.connectArchive(this);
		gpsAlertShown = false;
		checkNetwork();
		logger.LogMessage(this, "App resumed.");

		if (!settings.contains("close")) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage(
					"Crowd Traffic's normal behavior is to run in the background when you leave the app.\n" +
					"You can change this behavior and quit the app at any time from the Settings tab.\n\n" +
					"Do you want Crowd Traffic to run in the background?")
					.setCancelable(false)
					.setPositiveButton("Yes",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int id) {
									SharedPreferences.Editor edit = settings.edit();
									edit.putBoolean("close", false);
									edit.commit();
								}
							})
					.setNegativeButton("No",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int id) {
									SharedPreferences.Editor edit = settings.edit();
									edit.putBoolean("close", true);
									edit.commit();
								}
							});
			alert = builder.create();
			alert.show();
		}
		
		locMonitor.enterActiveMode();
		if(isOnline() && db.dataBuffer.readRecords().size() > 0 && settings.contains("buffer") && settings.getBoolean("buffer", false)){
			db.emptyDataBuffer();
		}
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		locMonitor.enterBackgroundMode();
	}

	private void checkNetwork() {
		showGPSalert = true;
		if(!networkConnectionAlertShown){
			if(!isOnline()){
	        	
	        	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	        	builder.setMessage("You are currently not connected to the internet. Crowd Traffic will not be able to access traffic data, however you can still contribute to the traffic maps by enabling \"Data Buffering\" in the settings panel.\n\n" +
	        			"Choose Continue to continue running Crowd Traffic without internet.\n\n" +
	        			"Choose Close to close the app.")
	        			.setCancelable(false)
	        			.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
			        		public void onClick(DialogInterface dialog, int id) {
			        			dialog.dismiss();
			        			checkNetwork();
			        			checkGPSEnabled();
			        		}
			        	}).setNegativeButton("Close", new DialogInterface.OnClickListener() {
			        		public void onClick(DialogInterface dialog, int id) {
			        			finish();
			        		}
			        	});
				if(alert != null && !alert.isShowing()){
					alert = builder.create();
					alert.show();
					networkConnectionAlertShown = true;
        			showGPSalert = false;
				}
	        	
	        }
		}
		
		if(!networkTypeAlertShown){
			if(isOnline()){
				
				if(connMan.getActiveNetworkInfo() != null && connMan.getActiveNetworkInfo().getType() == ConnectivityManager.TYPE_MOBILE){
		    		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		    		if(ConnectivityManager.isNetworkTypeValid(ConnectivityManager.TYPE_WIFI)){
						builder.setMessage("You are currently connected via your cellular network. This app frequently uses the internet which may result in a charge to your data plan.\n\n" +
								"Choose Continue to run the app.\n\n" +
								"Choose Close to close the app.\n\n" +
								"Choose WiFi if you are currently connected to a WiFi hotspot and wish to use that connection instead.")
						       .setCancelable(false)
						       .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
						           public void onClick(DialogInterface dialog, int id) {
						        	   dialog.cancel();
					        			checkNetwork();
					        			checkGPSEnabled();
						           }
						       })
						       .setNegativeButton("Close", new DialogInterface.OnClickListener() {
						           public void onClick(DialogInterface dialog, int id) {
						        	   finish();
						           }
						       })
						       .setNeutralButton("WiFi", new DialogInterface.OnClickListener() {
						    	   public void onClick(DialogInterface dialog, int which) {
						    		   ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).setNetworkPreference(ConnectivityManager.TYPE_WIFI);
					        			checkNetwork();
					        			checkGPSEnabled();
						    	   }
								});
		    		} else {
		    			builder.setMessage("You are currently connected via your cellular network. This app frequently uses the internet which may result in a charge to your data plan.\n\n" +
								"Choose Continue to run the app.\n\n" +
								"Choose Close to close the app.")
						       .setCancelable(false)
						       .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
						           public void onClick(DialogInterface dialog, int id) {
						        	   dialog.cancel();
					        			checkNetwork();
					        			checkGPSEnabled();
						           }
						       })
						       .setNegativeButton("Close", new DialogInterface.OnClickListener() {
						           public void onClick(DialogInterface dialog, int id) {
						        	   finish();
						           }
						       });
		    		}
					if(alert != null && !alert.isShowing()){
		    			alert = builder.create();
						alert.show();
						networkTypeAlertShown = true;
	        			showGPSalert = false;
		    		}
		    	}
				
			}
		}
		
		if(showGPSalert)checkGPSEnabled();
	}

	private void checkGPSEnabled() {
		if (!gpsAlertShown) {
			LocationManager locMngr = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
			if (!locMngr.isProviderEnabled(LocationManager.GPS_PROVIDER)
					&& !locMngr
							.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder
						.setMessage(
								"There are no location providers active on this device. Without location enabled, you will not be able to contribute to the traffic maps.\n\n"
										+ "Would you like to be taken to the location settings page so you can activate a location provider?")
						.setCancelable(false).setPositiveButton("Yes",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int id) {
										dialog.dismiss();
										launchGPSOptions();
									}
								}).setNegativeButton("No",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int id) {
										dialog.cancel();
									}
								});
				if (alert != null && !alert.isShowing()) {
					alert = builder.create();
					alert.show();
					gpsAlertShown = true;
				}
			} else if (!locMngr.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder
						.setMessage(
								"GPS is currently disabled. In order to upload the most accurate traffic data from this device, please enable GPS.")
						.setCancelable(false).setPositiveButton("Enable",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int id) {
										dialog.dismiss();
										launchGPSOptions();
									}
								}).setNegativeButton("Ignore",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int id) {
										dialog.cancel();
									}
								});
				if (alert != null && !alert.isShowing()) {
					alert = builder.create();
					alert.show();
					gpsAlertShown = true;
				}
			}
		}
	}
	
	private void launchGPSOptions() {
        ComponentName toLaunch = new ComponentName("com.android.settings","com.android.settings.SecuritySettings");
        final Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setComponent(toLaunch);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityForResult(intent, 0);
    }
	
	@Override
	protected void onUserLeaveHint() {
		super.onUserLeaveHint();
		if(settings.getBoolean("close", false)){
			finish();
		}
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		logger.LogMessage(this, "App closed.");
		logger.endLogging();
		connMan = null;
	}
	
	
	/**
	 * Called when locMonitor detects a new GPS location.
	 */
 	public void onNewLocation(Location location) {
		logger.LogMessage(this, "Recieved new GPS location. (" + location.getLatitude() + ", " + location.getLongitude() + ")");
		
		if( prevLoc != null && ( location.getLatitude() == prevLoc.getLatitude() && location.getLongitude() == prevLoc.getLongitude() ) ){
			logger.LogMessage(this, "Ignoring new location because it is the same as previous location.");
			return;
		}
		
		if(!isOnline() && connectedToInternet){
			logger.LogMessage(this, "Internet connection lost");
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
        	builder.setMessage("You are currently not connected to the internet. Crowd Traffic will not be able to access traffic data, however you can still contribute to the traffic maps by enabling \"Data Buffering\" in the settings panel.\n\n" +
        			"Choose Continue to continue running Crowd Traffic without internet.\n\n" +
        			"Choose Close to close the app.")
        			.setCancelable(false)
        			.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
		        		public void onClick(DialogInterface dialog, int id) {
		        			dialog.cancel();
		        		}
		        	}).setNegativeButton("Close", new DialogInterface.OnClickListener() {
		        		public void onClick(DialogInterface dialog, int id) {
		        			finish();
		        		}
		        	});
        	while(alert.isShowing());
			alert = builder.create();
			alert.show();
			db.disconnect();
			connectedToInternet = false;
		} else if(isOnline() && !connectedToInternet){
			logger.LogMessage(this, "Internet connection found.");
			Toast.makeText(this, "Crowd Traffic\nReconnecting", Toast.LENGTH_SHORT);
			db.connectLive(this);
			db.connectArchive(this);
			db.emptyDataBuffer();
			connectedToInternet = true;
		}
		
		TrafficRecord newRecord = null;
		try {
			location.setTime(System.currentTimeMillis());
			
			String streetname = "";
			
			if(isOnline()){
				try {
					streetname = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1).get(0).getThoroughfare();
				} catch (Exception e) {
					logger.LogMessage(this, "Error getting street name:" + e.toString());
				}
			}
			
			//If there is no previous location yet, make this location prevLoc and skip processing.
			if(prevLoc == null){
				prevLoc = location;
			} else {
				
				//If there is no previous record, create a new one.
				if(prevRecord == null){
					
					newRecord = new TrafficRecord(prevLoc, location, streetname);
					prevRecord = newRecord;
					
				} else {
					
					//if speed, direction, or street name have changed significantly, upload record and create new record.
					if(Math.abs(getSpeed(prevLoc, location) - prevRecord.speed()) > 10){
						
						db.storeRecord(prevRecord);
						prevRecord = new TrafficRecord(prevLoc, location, streetname);
						logger.LogMessage(this, "Uploaded new reccord.");
						
					} else if(Math.abs(getDirection(prevLoc, location) - prevRecord.direction()) > 25){
						
						db.storeRecord(prevRecord);
						prevRecord = new TrafficRecord(prevLoc, location, streetname);
						logger.LogMessage(this, "Uploaded new reccord.");
						
					} else if(streetname != prevRecord.streetName()){
						
						db.storeRecord(prevRecord);
						prevRecord = new TrafficRecord(prevLoc, location, streetname);
						logger.LogMessage(this, "Uploaded new reccord.");
						
						
					//Speed, direction, and street name are still consistent; thus, simply update existing record.
					} else {
						
						prevRecord.endLatitude((float) location.getLatitude());
						prevRecord.endLongitude((float) location.getLongitude());
						prevRecord.speed( (float) (( prevRecord.speed() + getSpeed(prevLoc, location) ) / 2));
						
					}
					
				}
			}
			prevLoc = location;
		} catch (Exception e) {
			logger.LogMessage(this, "Error handling GPS data:" + e.toString());
			Toast.makeText(this, "Crowd Traffic:\nError handling GPS data.", Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}
	}
	
	private float metersToMiles(float meters){
		return (float) (meters / 1609.344);
	}
	
	/**
	 * @return angle in degrees East from North
	 */
	private float getDirection(Location start, Location end){
		double xDiff = end.getLatitude() - start.getLatitude();
		double yDiff = end.getLongitude() - start.getLongitude();
		double dist = Math.sqrt( Math.pow(xDiff, 2) + Math.pow(yDiff, 2) );
		double sin = yDiff / dist;
		double cos = xDiff / dist;
		double dirRadians = Math.atan(sin/cos);
		if(Double.isNaN(dirRadians))dirRadians = 0;
//		if(dirRadians < 0) dirRadians += 2 * Math.PI;
//		if(dirRadians > 2 * Math.PI) dirRadians -= 2 * Math.PI;
		if(cos < 0) dirRadians += Math.PI;
		if(cos > 0 && dirRadians < 0) dirRadians += 2 * Math.PI;
		float dirDegrees = (float) ( ( dirRadians / ( Math.PI * 2 ) ) * 360.00 );
		dirDegrees = ( 360f -dirDegrees ) + 90f;
		return dirDegrees;
	}
	
	private double getSpeed(Location start, Location end){
		float timeDiff = (float) ( ( end.getTime() - start.getTime() ) / 3600000.00 );
		float locDiff = metersToMiles(end.distanceTo(start));
		return (locDiff / timeDiff);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.navigation_menu, menu);
		return true;
	}
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean active = settings.getBoolean("log", false);
		menu.findItem(R.id.menu_log).setVisible(active);
		menu.findItem(R.id.menu_log).setEnabled(active);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int currTab = tabHost.getCurrentTab();
		switch (item.getItemId()) {
		case R.id.menu_live:
			if(currTab != 0) prevTab = currTab;
			tabHost.setCurrentTab(0);
			return true;
		case R.id.menu_archive:
			if(currTab != 1) prevTab = currTab;
			tabHost.setCurrentTab(1);
			return true;
		case R.id.menu_settings:
			if(currTab != 2) prevTab = currTab;
			tabHost.setCurrentTab(2);
			return true;
		case R.id.menu_log:
			if(currTab != 3) prevTab = currTab;
			tabHost.setCurrentTab(3);
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	
	public static boolean isOnline(){
	    if (connMan != null) {
			NetworkInfo[] networks = connMan.getAllNetworkInfo();
			if(networks.length == 0)return false;
	    	if(settings != null && !settings.getBoolean("useNetwork", true)){
				for(NetworkInfo net : networks){
					if(net.getTypeName().equals("WIFI") && net.isConnected()){
						return true;
					}
				}
				return false;
	    	}
	    	for(NetworkInfo net : networks){
				if(net.isConnected()){
					return true;
				}
			}
			return false; //Internet is not connected
		} else return false; //ConnectivityManager is not defined. This is a sign that there is no instance of CrowdTrafficController active at this time.
	}
}