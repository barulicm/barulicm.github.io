package com.barulic.CrowdTraffic;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;
import java.util.TimeZone;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.barulic.CrowdTraffic.common.GeoRegion;
import com.barulic.CrowdTraffic.common.TrafficRecord;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;

/**
 * Activity that manages the Archived Map tab
 * @author Matt Barulic
 *
 */
public class ArchivedMapController extends MapActivity implements OnClickListener, LocationMonitorHost, OnSeekBarChangeListener {
	private TrafficDatabase db;
	private LocationMonitor locMonitor;
	
	private MapView map;
	private TextView hourView;
	private SeekBar hourSeek;
	private Spinner daySpinner;
	private ImageView fader;
	
	private SharedPreferences settings;
	
	private Logger logger;
	
	private long lastUpdate = 0;
	
	private boolean drawerIsShowing = false;
	
	private boolean active;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.archivedmap_layout);
        
        logger = CrowdTrafficController.logger;
        logger.LogMessage(this, "Starting archive map.");
        
        map = (MapView) findViewById(R.id.mapview);
        map.setBuiltInZoomControls(true);
        db = new TrafficDatabase(this);
        locMonitor = new LocationMonitor(this);
        locMonitor.startWatchingLocation();
        
        ((ImageView)findViewById(R.id.bottombarcross)).setOnClickListener(this);
        ((ImageView)findViewById(R.id.bottombarrefresh)).setOnClickListener(this);
        ((ImageView)findViewById(R.id.bottombarlogo)).setOnClickListener(this);
        ((ImageView)findViewById(R.id.archive_drawer_handle)).setOnClickListener(this);
        
        hourView = (TextView) findViewById(R.id.archive_hour_textview);
        hourSeek = (SeekBar) findViewById(R.id.archive_hour_seekbar);
        daySpinner = (Spinner) findViewById(R.id.archive_day_spinner);
        fader = (ImageView) findViewById(R.id.faderView);
        
        hourSeek.setOnSeekBarChangeListener(this);
        
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.days_of_week, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        daySpinner.setAdapter(adapter);
        
        settings = CrowdTrafficController.settings;
        
        map.getController().setZoom(16);
    	Location location = LocationMonitor.getLastLocation();
    	if(location != null) map.getController().animateTo(new GeoPoint((int)(location.getLatitude()*1e6), (int)(location.getLongitude()*1e6)));
    }
    
    @Override
    protected void onResume() {
    	super.onResume();
    	updateMap();
    	
    	daySpinner.setSelection(settings.getInt("archiveDay", 0));
    	hourSeek.setProgress(settings.getInt("archiveHour", 0));
    	active = true;
    }

    @Override
    protected void onPause() {
    	super.onPause();
    	active = false;
    }
    
	public void onNewLocation(Location location) {
		if (active) {
			if (System.currentTimeMillis() - lastUpdate >= 30000) {
				updateMap();
				lastUpdate = System.currentTimeMillis();
			}
			map.getController().animateTo(
					new GeoPoint((int) (location.getLatitude() * 1e6),
							(int) (location.getLongitude() * 1e6)));
		}
	}
	
	
	
	public void updateMap(){
		logger.LogMessage(this, "Updating map from database.");
		Thread t = new Thread(new Runnable(){
			public void run() {
				int hour = settings.getInt("archiveHour", 0);
				hour -= ( TimeZone.getDefault().getRawOffset() / 3600000 );
				hour--;
				if(hour < 0)hour = 0;
				int time = ( settings.getInt("archiveDay", 0) * 100 ) + hour;
				logger.LogMessage(this, "Asking for records at time: " + time);
				GeoPoint center = map.getMapCenter();
				float latSpan = map.getLatitudeSpan() / 1e6f;
				float longSpan = map.getLongitudeSpan() / 1e6f;
				GeoRegion region = new GeoRegion( ( center.getLatitudeE6() / 1e6f ) + latSpan / 2, ( center.getLatitudeE6() / 1e6f ) - latSpan / 2, ( center.getLongitudeE6() / 1e6f ) - longSpan / 2, ( center.getLongitudeE6() / 1e6f ) + longSpan / 2);
				region.time(time);
				ArrayList<TrafficRecord> records = db.getArchivedRecords(region);
				map.getOverlays().clear();
				final List<Overlay> newOverlays = new ArrayList<Overlay>();
				for (TrafficRecord r : records) {
					TrafficOverlay overlay = new TrafficOverlay(r, settings);
					newOverlays.add(overlay);
				}
				//Try to add new overlays, if this fails because the map is using the overlays, try again until it succeeds
				while (true) {
					try {
						map.post(new Runnable(){
							public void run() {
								map.getOverlays().addAll(newOverlays);
							};
						});
						break;
					} catch (ConcurrentModificationException e) {
						continue;
					}
				}
				CrowdTrafficController.uiHandler.post(new Runnable(){
					public void run() {
						Toast.makeText(CrowdTrafficController.rootActivity, "Map updated.", Toast.LENGTH_SHORT).show();
						map.invalidate();
					}
				});
			}
		});
		t.start();
	}

	/**
	 * This is only here because Google likes to keep track of things.
	 * This activity never shows directions, so this always returns false.
	 */
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}

	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.bottombarcross:
			db.clearArchiveRecords();
			updateMap();
			Toast.makeText(this, "Records cleared.", Toast.LENGTH_SHORT).show();
			break;

		case R.id.bottombarrefresh:
			updateMap();
			break;

		case R.id.bottombarlogo:
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage("You are about to visit the SensorWeb Lab homepage.\nDo you wish to continue?")
			       .setCancelable(false)
			       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			        	   Intent i = new Intent(Intent.ACTION_VIEW);
			        	   i.setData(Uri.parse("http://sensorweb.cs.gsu.edu/"));
			        	   startActivity(i);
			           }
			       })
			       .setNegativeButton("No", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			                dialog.cancel();
			           }
			       });
			AlertDialog alert = builder.create();
			alert.show();
			break;
		case R.id.archive_drawer_handle:
			if(drawerIsShowing){
				findViewById(R.id.archivedrawer).setVisibility(View.GONE);
				fader.setVisibility(View.GONE);
				SharedPreferences.Editor editor = settings.edit();
				editor.putInt("archiveHour", hourSeek.getProgress());
				editor.putInt("archiveDay", daySpinner.getSelectedItemPosition());
				editor.commit();
				drawerIsShowing = false;
				updateMap();
			} else {
				findViewById(R.id.archivedrawer).setVisibility(View.VISIBLE);
				fader.setVisibility(View.VISIBLE);
				drawerIsShowing = true;
			}
			break;
		}
	}

	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		
		hourView.setText(hourSeek.getProgress() + ":00");
		
	}

	public void onStartTrackingTouch(SeekBar seekBar) {}

	public void onStopTrackingTouch(SeekBar seekBar) {}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			TabHost tabs = CrowdTrafficController.tabHost;
			if(tabs != null){
				tabs.setCurrentTab(CrowdTrafficController.prevTab);
			}
			return true;
		}
		else return super.onKeyDown(keyCode, event);
	}
}
