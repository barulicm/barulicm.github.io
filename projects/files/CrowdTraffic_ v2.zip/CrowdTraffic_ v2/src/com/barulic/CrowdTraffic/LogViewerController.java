package com.barulic.CrowdTraffic;

import java.io.FileInputStream;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TabHost;
import android.widget.TextView;

import com.barulic.CrowdTraffic.common.TrafficRecord;

public class LogViewerController extends Activity {
	
	private TextView logView;
	private ScrollView scrollView;
	private Thread readThread;
	private Button refreshButton;
	private boolean runningThread = false;
	
	private Button buffButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.log_viewer_layout);
		logView = (TextView) findViewById(R.id.log_viewer_textview);
		scrollView = (ScrollView) findViewById(R.id.log_viewer_scrollview);
		refreshButton = (Button)findViewById(R.id.log_viewer_refreshbutton);
		refreshButton.setOnClickListener(new OnClickListener(){
			public void onClick(View view) {
				readLog();
			}
		});
		refreshButton.setEnabled(true);
		logView.setText("Loading file...");
		
		buffButton = (Button)findViewById(R.id.buffButton);
		buffButton.setOnClickListener(new OnClickListener(){
			public void onClick(View view){
				readBuffer();
			}
		});
		((Button)findViewById(R.id.emptybuffButton)).setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				CrowdTrafficController.db.emptyDataBuffer();
				readLog();
			}
		});
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		readLog();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if(readThread != null && readThread.isAlive())
		{
			runningThread = false;
		}
	}
	
	private void readLog(){
		if(!runningThread){
			readThread = new Thread(new Runnable(){
				public void run() {
					setRefreshButton(false);
					try {
						FileInputStream file = openFileInput("Crowd_Traffic_Log_File");
						if(!runningThread)return;
						byte[] bytes = new byte[file.available()];
						if(!runningThread)return;
						int result = file.read(bytes);
						if(!runningThread)return;
						if (result != -1) {
							String logText = new String(bytes);
							if(!runningThread)return;
							String[] lines = logText.split("\n");
							if(!runningThread)return;
							String tmp;
							for(int i=0; i < lines.length/2; i++){
								tmp = lines[i];
								lines[i] = lines[lines.length - ( i + 1 ) ];
								lines[lines.length - ( i + 1 ) ] = tmp;
								if(!runningThread)return;
							}
							StringBuffer newLogText = new StringBuffer();
							for(String s : lines)
							{
								newLogText.append(s + "\n");
								if(!runningThread)return;
							}
							displayMessage(newLogText.toString());
							if(!runningThread)return;
						} else throw new Exception("Empty log file.");
						scrollView.post(new Runnable()
					    {
					        public void run()
					        {
					        	scrollView.fullScroll(View.FOCUS_UP);
					        }
					    });
						runningThread = false;
					} catch (Exception e) {
						logView.setText("Error reading log file.\n" + e.toString());
					}
					setRefreshButton(true);
				}
				
				private void displayMessage(final String msg){
					scrollView.post(new Runnable(){
						public void run() {
							logView.setText(msg);
						}
					});
				}
				
				private void setRefreshButton(final boolean enabled){
					refreshButton.post(new Runnable(){
						public void run(){
							refreshButton.setEnabled(enabled);
							if(!enabled)refreshButton.setText("Loading...");
							else refreshButton.setText("Refresh");
						}
					});
				}
			});
			runningThread = true;
			readThread.start();
		}
	}
	


	private void readBuffer() {
		if(!runningThread){
			if(readThread != null)readThread.stop();
			readThread = new Thread(new Runnable(){
				public void run() {
					setRefreshButton(false);
					try {
						List<TrafficRecord> records = TrafficDatabase.dataBuffer.readRecords();
						StringBuffer display = new StringBuffer();
						for(TrafficRecord r : records){
							display.append(r);
							display.append("\n");
						}
						if(records.size() == 0)display.append("Buffer is empty.");
						displayMessage(display.toString());
						scrollView.post(new Runnable()
					    {
					        public void run()
					        {
					        	scrollView.fullScroll(View.FOCUS_UP);
					        }
					    });
					} catch (Exception e) {
						displayMessage("Error reading buffer file.\n" + e.getMessage());
					}
					setRefreshButton(true);
					runningThread = false;
				}
				
				private void displayMessage(final String msg){
					scrollView.post(new Runnable(){
						public void run() {
							logView.setText(msg);
						}
					});
				}
				
				private void setRefreshButton(final boolean enabled){
					refreshButton.post(new Runnable(){
						public void run(){
							refreshButton.setEnabled(enabled);
							if(!enabled)refreshButton.setText("Loading...");
							else refreshButton.setText("Refresh");
						}
					});
				}
			});
			runningThread = true;
			readThread.start();
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			TabHost tabs = CrowdTrafficController.tabHost;
			if(tabs != null){
				tabs.setCurrentTab(CrowdTrafficController.prevTab);
			}
			return true;
		}
		else return super.onKeyDown(keyCode, event);
	}
	
}
