package com.barulic.CrowdTraffic;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.barulic.CrowdTraffic.common.TrafficRecord;

/**
 * This class manages writing/reading records into and out of the buffer file
 * 
 * @author Matt Barulic
 *
 */
public class DataBuffer {

	private final String filename = "Crowd_Traffic_Buffer_File";
	private FileOutputStream fileOut;
	private FileInputStream fileIn;
	private SharedPreferences settings;
	private Activity host;
	private boolean isOpen = false;
	private Logger logger;
	
	public DataBuffer(Activity host) {
		this.host = host;
		logger = CrowdTrafficController.logger;
	}
	
	public boolean openBuffer(){
		try {
			if(isOpen) return true;
			fileOut = host.openFileOutput(filename, Context.MODE_APPEND);
			isOpen = true;
			return true;
		} catch (Exception e) {
			Toast.makeText(host, "Error opening log file.", Toast.LENGTH_LONG);
			return false;
		}
	}
	
	/**
	 * Stores record into buffer file as id/time/direction/speed/stname/slat/slong/elat/elong
	 * @param record
	 */
	public void storeRecord(TrafficRecord record){
		StringBuffer data = new StringBuffer();
		data.append(record.id());
		data.append("/");
		data.append(record.time());
		data.append("/");
		data.append(record.direction());
		data.append("/");
		data.append(record.speed());
		data.append("/");
		data.append(record.streetName());
		data.append("/");
		data.append(record.startLatitude());
		data.append("/");
		data.append(record.startLongitude());
		data.append("/");
		data.append(record.endLatitude());
		data.append("/");
		data.append(record.endLongitude());
		data.append("\n");
		try {
			fileOut.write(data.toString().getBytes());
			logger.LogMessage(this, "Data Buffer write complete.");
		} catch (Exception e) {
			Toast.makeText(host, "Error writing to Data Buffer.", Toast.LENGTH_SHORT);
			logger.LogMessage(this, "Data Buffer write failed: " + e.toString());
		}
	}
	
	public ArrayList<TrafficRecord> readRecords(){
		
		try {
			
			fileIn = host.openFileInput(filename);
			byte[] bytes = new byte[fileIn.available()];
			fileIn.read(bytes);
			String file = new String(bytes);
			String[] records = file.split("\n");
			String[] values;
			ArrayList<TrafficRecord> results = new ArrayList<TrafficRecord>(records.length);
			for(String s : records){
				if (s.contains("/")) {
					values = s.split("/");
					if (values.length > 0) {
						TrafficRecord r = new TrafficRecord();
						//				id/time/direction/speed/stname/slat/slong/elat/elong
						if(!values[0].equals("null"))
							r.id(Long.decode(values[0]));
						r.time(Long.decode(values[1]).longValue());
						r.direction(Float.parseFloat(values[2]));
						r.speed(Float.parseFloat(values[3]));
						r.streetName(values[4]);
						r.startLatitude(Float.parseFloat(values[5]));
						r.startLongitude(Float.parseFloat(values[6]));
						r.endLatitude(Float.parseFloat(values[7]));
						r.endLongitude(Float.parseFloat(values[8]));
						results.add(r);
					}
				}
			}
			fileIn.close();
			return results;
			
		} catch (Exception e) {
			logger.LogMessage(this, "Error reading from Data Buffer: " + e.toString());
			return new ArrayList<TrafficRecord>(0);
		}
		
	}
	
	public ArrayList<TrafficRecord> readAndRemoveRecords(){
		ArrayList<TrafficRecord> results = readRecords();
		
		try {
			
			if(!isOpen) 
				fileOut = host.openFileOutput(filename, Context.MODE_PRIVATE);
			fileOut.write(("").getBytes());
			if(!isOpen)
				fileOut.close();
			
		} catch (Exception e) {
			logger.LogMessage(this, "Failed to clear Data Buffer: " + e.toString());
		}
		
		return results;
	}
	
	public TrafficRecord readTopRecord(){
		ArrayList<TrafficRecord> records = readRecords();
		if (records.size() > 0) {
			return records.get(0);
		} else return null;
	}
	
	public TrafficRecord readAndRemoveTopRecord(){
		TrafficRecord result = readTopRecord();
		
		try {
			
			if(!isOpen) 
				fileOut = host.openFileOutput(filename, Context.MODE_PRIVATE);
			
			fileIn = host.openFileInput(filename);
			byte[] bytes = new byte[fileIn.available()];
			fileIn.read(bytes);
			String file = new String(bytes);
			StringBuffer allButFirst = new StringBuffer();
			String[] records = file.split("\n");
			for(int i = 1; i < records.length; i++){
				allButFirst.append(records[i]);
			}
			fileOut.write(allButFirst.toString().getBytes());
			
			if(!isOpen)
				fileOut.close();
			
		} catch (Exception e) {
			logger.LogMessage(this, "Failed to remove top record from Data Buffer: " + e.toString());
		}
		
		return result;
	}
	
	public boolean closeBuffer(){
		if(!isOpen)return true;
		try {
			fileOut.close();
			isOpen = false;
			return true;
		} catch (Exception e) {
			Toast.makeText(host, "Error closing log file.", Toast.LENGTH_LONG);
			return false;
		}
	}

}
