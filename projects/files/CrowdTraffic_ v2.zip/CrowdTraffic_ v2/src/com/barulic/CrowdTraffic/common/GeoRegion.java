package com.barulic.CrowdTraffic.common;

import java.io.Serializable;

public class GeoRegion implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private float _top, _bottom, _left, _right;
	private int _time;

	public GeoRegion() {
		this(0,0,0,0,0);
	}
	
	public GeoRegion(float top, float bottom, float left, float right){
		this(top, bottom, left, right, 0);
	}
	
	public GeoRegion(float top, float bottom, float left, float right, int time){
		_time = time;
		_top = top;
		_bottom = bottom;
		_left = left;
		_right = right;
	}
	
	public float top(){
		return _top;
	}
	
	public void top(float top){
		_top = top;
	}
	
	public float bottom(){
		return _bottom;
	}
	
	public void bottom(float bottom){
		_bottom = bottom;
	}
	
	public float left(){
		return _left;
	}
	
	public void left(float left){
		_left = left;
	}
	
	public float right(){
		return _right;
	}
	
	public void right(float right){
		_right = right;
	}
	
	public int time(){
		return _time;
	}
	
	public void time(int time){
		_time = time;
	}
	
	public boolean containsPoint(float latitude, float longitude){
		return (latitude < _top && latitude > _bottom && longitude > _left && longitude < _right);
	}

}
