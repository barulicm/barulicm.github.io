package com.barulic.CrowdTraffic;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.Toast;

import com.barulic.CrowdTraffic.common.GeoRegion;
import com.barulic.CrowdTraffic.common.TrafficRecord;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;

/**
 * Activity that manages the Live Map tab.
 * @author Matt Barulic
 *
 */
public class LiveMapController extends MapActivity implements OnClickListener, LocationMonitorHost {
	private TrafficDatabase db;
	private LocationMonitor locMonitor;
	
	private MapView map;
	
	private SharedPreferences settings;
	
	private Logger logger;
	
	private long lastUpdate = 0;
	
	private boolean active;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.livemap_layout);
        
        logger = CrowdTrafficController.logger;
        logger.LogMessage(this, "Starting live map.");
        
        map = (MapView) findViewById(R.id.mapview);
        map.setBuiltInZoomControls(true);
        db = new TrafficDatabase(this);
        locMonitor = new LocationMonitor(this);
        locMonitor.startWatchingLocation();
        
        ((ImageView)findViewById(R.id.bottombarcross)).setOnClickListener(this);
        ((ImageView)findViewById(R.id.bottombarrefresh)).setOnClickListener(this);
        ((ImageView)findViewById(R.id.bottombarlogo)).setOnClickListener(this);
        
        settings = CrowdTrafficController.settings;
        
        map.getController().setZoom(17);
    	Location location = LocationMonitor.getLastLocation();
    	if(location != null) map.getController().animateTo(new GeoPoint((int)(location.getLatitude()*1e6), (int)(location.getLongitude()*1e6)));
    }
    
    @Override
    protected void onResume() {
    	super.onResume();
    	updateMap();
    	active = true;
    }
    
    @Override
    protected void onPause() {
    	super.onPause();
    	active = false;
    }
    
    @Override
    protected void onDestroy() {
    	super.onDestroy();
    	logger.LogMessage(this, "Live map ending.");
    }
    
	public void onNewLocation(Location location) {
		if (active) {
			if (System.currentTimeMillis() - lastUpdate >= 30000) {
				updateMap();
				lastUpdate = System.currentTimeMillis();
			}
			map.getController().animateTo(
					new GeoPoint((int) (location.getLatitude() * 1e6),
							(int) (location.getLongitude() * 1e6)));
		}
	}
	
	public void updateMap(){
		logger.LogMessage(this, "Updating map from database.");
		Thread t = new Thread(new Runnable(){
			public void run() {
				GeoPoint center = map.getMapCenter();
				float latSpan = map.getLatitudeSpan() / 1e6f;
				float longSpan = map.getLongitudeSpan() / 1e6f;
				GeoRegion region = new GeoRegion( ( center.getLatitudeE6() / 1e6f ) + latSpan / 2, ( center.getLatitudeE6() / 1e6f ) - latSpan / 2, ( center.getLongitudeE6() / 1e6f ) - longSpan / 2, ( center.getLongitudeE6() / 1e6f ) + longSpan / 2);
				ArrayList<TrafficRecord> records = db.getRecords(region);
				map.getOverlays().clear();
				map.getOverlays().clear();
				final List<Overlay> newOverlays = new ArrayList<Overlay>();
				for (TrafficRecord r : records) {
					TrafficOverlay overlay = new TrafficOverlay(r, settings);
					newOverlays.add(overlay);
				}
				//Try to add new overlays, if this fails because the map is using the overlays, try again until it succeeds
				while (true) {
					try {
						map.post(new Runnable(){
							public void run() {
								map.getOverlays().addAll(newOverlays);
							};
						});
						break;
					} catch (ConcurrentModificationException e) {
						continue;
					}
				}
				CrowdTrafficController.uiHandler.post(new Runnable(){
					public void run() {
						Toast.makeText(CrowdTrafficController.rootActivity, "Map updated.", Toast.LENGTH_SHORT).show();
						map.invalidate();
					}
				});
			}
		});
		t.start();
	}

	/**
	 * This is only here because Google likes to keep track of things.
	 * This activity never shows directions, so this always returns false.
	 */
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}

	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.bottombarcross:
			db.clearLiveRecords();
			updateMap();
			Toast.makeText(this, "Records cleared.", Toast.LENGTH_SHORT).show();
			break;

		case R.id.bottombarrefresh:
			updateMap();
			break;

		case R.id.bottombarlogo:
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage("You are about to visit the SensorWeb Lab homepage.\nDo you wish to continue?")
			       .setCancelable(false)
			       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			        	   Intent i = new Intent(Intent.ACTION_VIEW);
			        	   i.setData(Uri.parse("http://sensorweb.cs.gsu.edu/"));
			        	   startActivity(i);
			           }
			       })
			       .setNegativeButton("No", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			                dialog.cancel();
			           }
			       });
			AlertDialog alert = builder.create();
			alert.show();
			break;
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			TabHost tabs = CrowdTrafficController.tabHost;
			if(tabs != null){
				tabs.setCurrentTab(CrowdTrafficController.prevTab);
			}
			return true;
		}
		else return super.onKeyDown(keyCode, event);
	}
}
