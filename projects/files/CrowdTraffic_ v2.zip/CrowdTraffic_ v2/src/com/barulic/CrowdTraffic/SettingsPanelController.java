package com.barulic.CrowdTraffic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

/**
 * Activity that manages the Settings tab
 * @author Matt Barulic
 *
 */
public class SettingsPanelController extends Activity implements OnSeekBarChangeListener, OnClickListener {

	private int screenWidth = 0;
	private SharedPreferences settings;
	private SeekBar highBar;
	private SeekBar lowBar;
	private ToggleButton logToggle;
	private ToggleButton buffToggle;
	private ToggleButton networkToggle;
	private ToggleButton closeToggle;
	private ImageView networkIndicator;
	private Logger logger;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings_layout);
		
		logger = CrowdTrafficController.logger;
		logger.LogMessage(this, "Opening settings panel");
		
		highBar = (SeekBar)findViewById(R.id.highspeedseek);
		lowBar = (SeekBar)findViewById(R.id.lowspeedseek);
		logToggle = (ToggleButton)findViewById(R.id.settings_log_toggle);
		buffToggle = (ToggleButton)findViewById(R.id.settings_buff_toggle);
		networkToggle = (ToggleButton)findViewById(R.id.use_network_toggle);
		closeToggle = (ToggleButton)findViewById(R.id.closeToggle);
		
		networkIndicator = (ImageView)findViewById(R.id.networkIndicator);
		
		highBar.setOnSeekBarChangeListener(this);
		lowBar.setOnSeekBarChangeListener(this);
		((ImageView)findViewById(R.id.bottombarsave)).setOnClickListener(this);
		((ImageView)findViewById(R.id.bottombarlogo)).setOnClickListener(this);
		( (ImageView)findViewById(R.id.bottombarcross)).setOnClickListener(this);
		
		screenWidth = ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getWidth();
		
		settings = CrowdTrafficController.settings;
		
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			TabHost tabs = CrowdTrafficController.tabHost;
			if(tabs != null){
				tabs.setCurrentTab(CrowdTrafficController.prevTab);
			}
			return true;
		}
		else return super.onKeyDown(keyCode, event);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		lowBar.setProgress(settings.getInt("lowSpeed", 10));
		highBar.setProgress(settings.getInt("upSpeed", 35));
		logToggle.setChecked(settings.getBoolean("log", false));
		buffToggle.setChecked(settings.getBoolean("buffer", false));
		networkToggle.setChecked(settings.getBoolean("useNetwork", false));
		closeToggle.setChecked(!settings.getBoolean("close", false));
		if(CrowdTrafficController.isOnline())
			networkIndicator.setImageDrawable(getResources().getDrawable(R.drawable.greendot));
		else
			networkIndicator.setImageDrawable(getResources().getDrawable(R.drawable.reddot));
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		saveSettings();
	}
	
	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		if(fromUser){
			if(seekBar.getId() == R.id.lowspeedseek){
				
				if(progress >= highBar.getProgress()) seekBar.setProgress(highBar.getProgress() - 1);
				
			} else if(seekBar.getId() == R.id.highspeedseek){
				
				if(progress <= lowBar.getProgress()) seekBar.setProgress(lowBar.getProgress() + 1);
				
			}
		}
		((TextView)findViewById(R.id.lowSpeedText)).setText("Low speed : " + lowBar.getProgress());
		((TextView)findViewById(R.id.highSpeedText)).setText("High speed : " + highBar.getProgress());
		
		int highLevel = highBar.getProgress();
		int lowLevel = lowBar.getProgress();
		int w;
		ImageView reddot = (ImageView)findViewById(R.id.reddotview);
		w = (int) (( lowLevel / 100.00 ) * screenWidth);
		reddot.getLayoutParams().width = w;
		reddot.invalidate();
		ImageView yellowdot = (ImageView)findViewById(R.id.yellowdotview);
		w = (int) (( ( highLevel - lowLevel ) / 100.00 ) * screenWidth);
		yellowdot.getLayoutParams().width = w;
		yellowdot.invalidate();
		ImageView greendot = (ImageView)findViewById(R.id.greendotview);
		w = (int) (( ( 100.00 - highLevel ) / 100.00 ) * screenWidth);
		greendot.getLayoutParams().width = w;
		greendot.invalidate();
	}

	public void onStartTrackingTouch(SeekBar seekBar) {}

	public void onStopTrackingTouch(SeekBar seekBar) {}

	public void onClick(View v) {
		switch (v.getId()){
		case R.id.bottombarsave:
			saveSettings();
			Toast.makeText(this, "Settings saved.", Toast.LENGTH_SHORT).show();
			break;
		case R.id.bottombarlogo:
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage("You are about to visit the SensorWeb Lab homepage.\nDo you wish to continue?")
			       .setCancelable(false)
			       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			        	   Intent i = new Intent(Intent.ACTION_VIEW);
			        	   i.setData(Uri.parse("http://sensorweb.cs.gsu.edu/"));
			        	   startActivity(i);
			           }
			       })
			       .setNegativeButton("No", new DialogInterface.OnClickListener() {
			           public void onClick(DialogInterface dialog, int id) {
			                dialog.cancel();
			           }
			       });
			AlertDialog alert = builder.create();
			alert.show();
			break;
		case R.id.bottombarcross:
			CrowdTrafficController.rootActivity.finish();
			break;
		}
	}
	
	private boolean saveSettings(){
		logger.LogMessage(this, "Saving settings...");
		try {
			SharedPreferences.Editor editor = settings.edit();
			editor.putInt("lowSpeed", lowBar.getProgress());
			editor.putInt("upSpeed", highBar.getProgress());
			editor.putBoolean("log", logToggle.isChecked());
			editor.putBoolean("buffer", buffToggle.isChecked());
			editor.putBoolean("useNetwork", networkToggle.isChecked());
			editor.putBoolean("close", !closeToggle.isChecked());
			editor.commit();
			logger.LogMessage(this, "Settings saved.");
		} catch (Exception e) {
			Toast.makeText(this, "Error saving settings.", Toast.LENGTH_SHORT);
			logger.LogMessage(this, "Error saving settings: " + e.toString());
		}
		return true;
	}
	
}
