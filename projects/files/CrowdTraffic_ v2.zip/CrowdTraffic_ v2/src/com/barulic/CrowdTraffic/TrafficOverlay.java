package com.barulic.CrowdTraffic;

import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;

import com.barulic.CrowdTraffic.common.TrafficRecord;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

public class TrafficOverlay extends Overlay {
	private TrafficRecord _record;
	private SharedPreferences _settings;

	public TrafficOverlay(TrafficRecord record, SharedPreferences settings){
		super();
		setRecord(record);
		setSettings(settings);
	}
	
	@Override
	public void draw(Canvas canvas, MapView mapView, boolean shadow) {
		super.draw(canvas, mapView, shadow);
		if(!shadow){
			Projection proj = mapView.getProjection();
			Point start = proj.toPixels(getRecord().getStartGeoPoint(), null);
			Point end = proj.toPixels(getRecord().getEndGeoPoint(), null);
			Path path = new Path();
			path.moveTo(start.x, start.y);
			path.lineTo(end.x, end.y);

			Paint paint = new Paint();
			paint.setDither(true);
			
			//set icon color based on user speed settings
			if (getRecord().speed() <= _settings.getInt("lowSpeed", 10))
				paint.setColor(Color.RED);
			else if (getRecord().speed() <= _settings.getInt("upSpeed", 35))
				paint.setARGB(255, 255, 153, 0);
			else
				paint.setColor(Color.GREEN);
			
			paint.setStyle(Paint.Style.FILL_AND_STROKE);
			paint.setStrokeJoin(Paint.Join.ROUND);
			paint.setStrokeCap(Paint.Cap.ROUND);
			paint.setStrokeWidth(5);

			canvas.drawPath(path, paint);
		}
	}

	public void setRecord(TrafficRecord record) {
		this._record = record;
	}

	public TrafficRecord getRecord() {
		return _record;
	}

	public void setSettings(SharedPreferences _settings) {
		this._settings = _settings;
	}

	public SharedPreferences getSettings() {
		return _settings;
	}
}
