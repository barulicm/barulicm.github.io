package com.barulic.CrowdTraffic;

import android.location.Location;

/**
 * Interface for a class that wishes to recieve updates from a LocationMonitor instance
 * @author Matt Barulic
 *
 */
public interface LocationMonitorHost {
	public void onNewLocation(Location location);
}
