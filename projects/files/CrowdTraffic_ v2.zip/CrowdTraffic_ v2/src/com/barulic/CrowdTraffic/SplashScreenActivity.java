package com.barulic.CrowdTraffic;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

public class SplashScreenActivity extends Activity {

	protected boolean _active = true;
	protected int _splashTime = 1500; // time to display the splash screen in ms
	protected Context context;
	protected Thread splashThread;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.splashscreen_layout);
		
		context = this;
		
		// thread for displaying the SplashScreen
	    splashThread = new Thread() {
	        @Override
	        public void run() {
	            try {
	                int waited = 0;
	                while(_active && (waited < _splashTime)) {
	                    sleep(100);
	                    if(_active) {
	                        waited += 100;
	                    }
	                }
	            } catch(InterruptedException e) {
	                // do nothing
	            } finally {
	                startActivity(new Intent().setClass(context, CrowdTrafficController.class));
	        		finish();
	            }
	        }
	    };
	    splashThread.start();
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		splashThread.stop();
	}
	
}
