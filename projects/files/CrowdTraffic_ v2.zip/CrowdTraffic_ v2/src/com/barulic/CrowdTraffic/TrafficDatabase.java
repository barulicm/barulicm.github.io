package com.barulic.CrowdTraffic;

import java.util.ArrayList;
import java.util.Iterator;

import org.restlet.engine.Engine;
import org.restlet.ext.httpclient.HttpClientHelper;
import org.restlet.resource.ClientResource;

import android.app.Activity;
import android.content.SharedPreferences;
import android.location.Geocoder;
import android.widget.Toast;

import com.barulic.CrowdTraffic.common.GeoRegion;
import com.barulic.CrowdTraffic.common.TrafficRecord;
import com.barulic.CrowdTraffic.common.TrafficResourceInterface;

/**
 * Connects the android app to the App Engine databases.
 * @author Matt Barulic
 *
 */
public class TrafficDatabase {
	
	private ClientResource _crLive;
	private TrafficResourceInterface _resourceLive;
	private boolean _connectedLive;

	private ClientResource _crArchive;
	private TrafficResourceInterface _resourceArchive;
	private boolean _connectedArchive;
	
	private SharedPreferences settings;
	
	public static DataBuffer dataBuffer;
	
	private Activity _host;
	
	public TrafficDatabase(Activity host){
		connectLive(host);
		connectArchive(host);
		settings = CrowdTrafficController.settings;
		dataBuffer = new DataBuffer(host);
		_host = host;
		dataBuffer.openBuffer();
		dataBuffer.closeBuffer();

		Engine.getInstance().getRegisteredClients().clear();
		Engine.getInstance().getRegisteredClients().add(new HttpClientHelper(null));
	}

	public void clearLiveRecords() {
		if(_connectedLive)_resourceLive.clearRecords();
	}
	
	public void clearArchiveRecords() {
		if(_connectedArchive)_resourceArchive.clearRecords();
	}

	public ArrayList<TrafficRecord> getRecords(GeoRegion inRegion) {
		try {
			if (CrowdTrafficController.isOnline()) {
				if (_connectedLive)
					return _resourceLive.getRecords(inRegion);
				return new ArrayList<TrafficRecord>(0);
			} else {
				CrowdTrafficController.logger.LogMessage(this, "Could not get live records. There is no internet connection.");
				return new ArrayList<TrafficRecord>(0);
			}
		} catch (Exception e) {
			CrowdTrafficController.uiHandler.post(new Runnable(){
				public void run() {
					Toast.makeText(_host, "Error getting traffic records.", Toast.LENGTH_SHORT).show();
				}
			});
			CrowdTrafficController.logger.LogMessage(this, "Error getting live records : " + e.toString());
			return new ArrayList<TrafficRecord>(0);
		}
	}
	
	public ArrayList<TrafficRecord> getArchivedRecords(GeoRegion inRegion){
		try {
			if (CrowdTrafficController.isOnline()) {
				if(_connectedArchive)return _resourceArchive.getRecords(inRegion);
				return new ArrayList<TrafficRecord>(0);
			} else {
				CrowdTrafficController.logger.LogMessage(this, "Could not get archived records. There is no internet connection.");
				return new ArrayList<TrafficRecord>(0);
			}
		} catch (Exception e) {
			CrowdTrafficController.uiHandler.post(new Runnable(){
				public void run() {
					Toast.makeText(_host, "Error getting traffic records.", Toast.LENGTH_SHORT).show();
				}
			});
			CrowdTrafficController.logger.LogMessage(this, "Error getting archived records : " + e.toString());
			return new ArrayList<TrafficRecord>(0);
		}
	}

	/**
	 * Sends the new record to the live and archive databases.
	 * @param record
	 */
	public void storeRecord(final TrafficRecord record) {
		try {
			Thread t = new Thread(new Runnable(){
				public void run() {
					try {
						if (CrowdTrafficController.isOnline()) {
							if (_connectedLive)
								_resourceLive.storeRecord(record);
							if (_connectedArchive)
								_resourceArchive.storeRecord(record);
						} else {
							if(settings.getBoolean("buffer", false)){
								CrowdTrafficController.logger.LogMessage(this, "Buffering traffic record");
								dataBuffer.openBuffer();
								dataBuffer.storeRecord(record);
								dataBuffer.closeBuffer();
							}
						}
					} catch (Exception e) {
						CrowdTrafficController.logger.LogMessage(this, "Error uploading record:" + e.toString());
					}
				}
			});
			t.start();
		} catch (Exception e) {
			CrowdTrafficController.logger.LogMessage(this, "Error uploading record:" + e.toString());
		}
	}
	
	/**
	 * Sends the new record to the live and archive databases.
	 * Waits for completion before returning.
	 * @param record
	 */
	public void storeRecordWait(final TrafficRecord record){
		Thread t = null;
		try {
			t = new Thread(new Runnable() {
				public void run() {
					if (CrowdTrafficController.isOnline()) {
						if (_connectedLive)
							_resourceLive.storeRecord(record);
						if (_connectedArchive)
							_resourceArchive.storeRecord(record);
					} else {
						if (settings.getBoolean("buffer", false)) {
							CrowdTrafficController.logger.LogMessage(this,
									"Buffering traffic record");
							dataBuffer.openBuffer();
							dataBuffer.storeRecord(record);
							dataBuffer.closeBuffer();
						}
					}
				}
			});
			t.start();
		} catch (Exception e) {
			CrowdTrafficController.logger.LogMessage(this, "Error storing record :" + e.toString());
			CrowdTrafficController.uiHandler.post(new Runnable(){
				public void run() {
					Toast.makeText(_host, "Crowd Traffic:\nError uploading record.", Toast.LENGTH_SHORT).show();
				}
			});
		}
		try {
			if(t != null)t.join();
		} catch (InterruptedException e) {
			return;
		}
	}
	
	public void connectLive(Activity host){
		if (CrowdTrafficController.isOnline()) {
			//Connect to live database
			try {
				_crLive = new ClientResource(
						"http://crowdtraffic.appspot.com/db");
				_crLive.setRequestEntityBuffering(true);
				_crLive.setEntityBuffering(true);
				_crLive.setRetryOnError(false);

				_resourceLive = _crLive.wrap(TrafficResourceInterface.class);
				_connectedLive = true;
			} catch (Exception e) {
				_connectedLive = false;
				Toast.makeText(host.getApplicationContext(),
						"Crowd Traffic :\nUnable to connect to live database.",
						Toast.LENGTH_SHORT).show();
			}
		} else {
			CrowdTrafficController.logger.LogMessage(this, "Could not connect to live database. There is no internet connection.");
		}
	}
	
	public void connectArchive(Activity host){
		if (CrowdTrafficController.isOnline()) {
			//Connect to archive database
			try {
				_crArchive = new ClientResource(
						"http://crowdtraffic-archive.appspot.com/db");
				_crArchive.setRequestEntityBuffering(true);
				_crArchive.setEntityBuffering(true);
				_crArchive.setRetryOnError(false);

				_resourceArchive = _crArchive
						.wrap(TrafficResourceInterface.class);
				_connectedArchive = true;
			} catch (Exception e) {
				_connectedArchive = false;
				Toast.makeText(
						host.getApplicationContext(),
						"Crowd Traffic :\nUnable to connect to archive database.",
						Toast.LENGTH_SHORT).show();
			}
		} else {
			CrowdTrafficController.logger.LogMessage(this, "Could not connect to archive database. There is no internet connection.");
		}
	}
	
	public void emptyDataBuffer(){
		Thread t = new Thread(new Runnable(){
			public void run() {
				CrowdTrafficController.logger.LogMessage(this, "Emptying buffer...");
				CrowdTrafficController.uiHandler.post(new Runnable(){
					public void run() {
						Toast.makeText(_host, "Emptying buffer", Toast.LENGTH_SHORT).show();
					}
				});
				if (settings.getBoolean("buffer", false)) {
					if (_connectedArchive && _connectedLive
							&& CrowdTrafficController.isOnline()) {
						ArrayList<TrafficRecord> records = dataBuffer
								.readAndRemoveRecords();
						try {
							Iterator<TrafficRecord> iter = records.iterator();
							TrafficRecord r;
							while(iter.hasNext()){
								r = iter.next();
								Geocoder geocoder = new Geocoder(_host);
								String streetname = geocoder.getFromLocation(r.getStartLoc().getLatitude(), r.getStartLoc().getLongitude(), 1).get(0).getThoroughfare();
								r.streetName(streetname);
								storeRecordWait(r);
								iter.remove();
							}

						} catch (Exception e) {
							CrowdTrafficController.logger.LogMessage(this, "Failed to write records to database. Attempting to roll records back into data buffer. " + e.toString());
							dataBuffer.openBuffer();
							for (TrafficRecord r : records)
								dataBuffer.storeRecord(r);
							dataBuffer.closeBuffer();
						}
					}
				}
				CrowdTrafficController.logger.LogMessage(this, "Buffer Emptied.");
				CrowdTrafficController.uiHandler.post(new Runnable(){
					public void run() {
						Toast.makeText(_host, "Buffer Emptied.", Toast.LENGTH_SHORT).show();
					}
				});
			}
		});
		t.start();
	}
	
	public void disconnect(){
		_connectedArchive = false;
		_connectedLive = false;
	}
	
	public boolean isConnectedLive(){
		return _connectedLive && CrowdTrafficController.isOnline();
	}
	
	public boolean isConnectedArchive(){
		return _connectedArchive && CrowdTrafficController.isOnline();
	}

}
