package com.barulic.CrowdTraffic;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Class that wraps all of the necessary location code, increasing ease-of-use for location services in this app.
 * @author Matt Barulic
 *
 */
public class LocationMonitor implements LocationListener {
	private LocationMonitorHost _lmhost;
	private LocationManager locationManager;
	private static Activity _ahost;
	private static boolean hasGPSSignal = true;

	public LocationMonitor(Activity host) {
		_ahost = host;
		_lmhost = (LocationMonitorHost) host;
	}
	
	public void startWatchingLocation(){
		// Acquire a reference to the system Location Manager
        locationManager = (LocationManager) _ahost.getSystemService(Context.LOCATION_SERVICE);

        // Register the listener with the Location Manager to receive location updates
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, this);
	}

	public void onLocationChanged(Location location) {
		_lmhost.onNewLocation(location);
	}

	public void onProviderDisabled(String provider) {
		if(provider.equals(LocationManager.GPS_PROVIDER)){
			if(hasGPSSignal)Toast.makeText(_ahost, "Lost GPS signal.", Toast.LENGTH_SHORT).show();
			hasGPSSignal = false;
		}
	}

	public void onProviderEnabled(String provider) {
		if(provider.equals(LocationManager.GPS_PROVIDER)){
			if(!hasGPSSignal)Toast.makeText(_ahost, "Found GPS signal.", Toast.LENGTH_SHORT).show();
			hasGPSSignal = true;
		}
	}

	public void onStatusChanged(String provider, int status, Bundle extras) {}

	public static Location getLastLocation(){
		if(_ahost != null)
		{
			LocationManager locationManager = (LocationManager) _ahost.getSystemService(Context.LOCATION_SERVICE);
			Location gpsAnswer = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
			Location netAnswer = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
			if(gpsAnswer != null && netAnswer != null){
				if(gpsAnswer.getTime() > netAnswer.getTime()) return gpsAnswer;
				else return netAnswer;
			}
			if(gpsAnswer == null) return netAnswer;
			if(netAnswer == null) return gpsAnswer;
		}
		return null;
	}
	
	public void enterBackgroundMode(){
		CrowdTrafficController.logger.LogMessage(this, "Entering background mode. Reducing GPS activity.");
		locationManager.removeUpdates(this);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000, 1, this);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60000, 1, this);
	}
	
	public void enterActiveMode(){
		CrowdTrafficController.logger.LogMessage(this, "Entering active mode.");
		locationManager.removeUpdates(this);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, this);
	}
}
