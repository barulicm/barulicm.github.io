package com.barulic.CrowdTraffic.common;

import java.io.Serializable;

import android.location.Location;

import com.google.android.maps.GeoPoint;

public class TrafficRecord implements Serializable {

	private static final long serialVersionUID = 1L;

	private float _startLat, _startLong, _endLat, _endLong, _speed, _direction;
	private long _time;
	private String _streetName;
	@SuppressWarnings("unused")
	private Long _id;
	
	public TrafficRecord(float startLatitude, float startLongitude, float endLatitude, float endLongitude, float speed, float direction, String streetName, long time) {
		_startLat = startLatitude;
		_startLong = startLongitude;
		_endLat = endLatitude;
		_endLong = endLongitude;
		_speed = speed;
		_direction = direction;
		_time = time;
		_streetName = streetName;
	}
	
	public TrafficRecord() {
		this(0, 0, 0, 0, 0, 0, "",0);
	}
	
	public TrafficRecord(Location start, Location end, String streetName){
//		//Average coordinates of two location objects
//		latitude((float) ( end.getLatitude() + start.getLatitude() ) / 2f );
//		longitude((float) ( end.getLongitude() + start.getLongitude() ) / 2f );
		startLatitude((float) start.getLatitude());
		startLongitude((float) start.getLongitude());
		endLatitude((float) end.getLatitude());
		endLongitude((float) end.getLongitude());
		time(end.getTime());
		//Determine speed using this location and prevLoc
		float timeDiff = (float) ( ( end.getTime() - start.getTime() ) / 3600000.00 );
		float locDiff = metersToMiles(end.distanceTo(start));
		speed(locDiff / timeDiff);
		//Determine direction
		direction(getDirection(end, start));
		_streetName = streetName;
	}
	
	private float metersToMiles(float meters){
		return (float) (meters / 1609.344);
	}
	
	/**
	 * @return angle in degrees where 0 = East
	 */
	private float getDirection(Location start, Location end){
		double xDiff = end.getLatitude() - start.getLatitude();
		double yDiff = end.getLongitude() - start.getLongitude();
		double dist = Math.sqrt( Math.pow(xDiff, 2) + Math.pow(yDiff, 2) );
		double sin = yDiff / dist;
		double cos = xDiff / dist;
		double dirRadians = Math.atan(sin/cos);
		if(Double.isNaN(dirRadians))dirRadians = 0;
//		if(dirRadians < 0) dirRadians += 2 * Math.PI;
//		if(dirRadians > 2 * Math.PI) dirRadians -= 2 * Math.PI;
		if(cos < 0) dirRadians += Math.PI;
		if(cos > 0 && dirRadians < 0) dirRadians += 2 * Math.PI;
		float dirDegrees = (float) ( ( dirRadians / ( Math.PI * 2 ) ) * 360.00 );
		dirDegrees = ( 360f -dirDegrees ) + 90f;
		return dirDegrees;
	}
	
	public Location getStartLoc(){
		Location loc = new Location("");
		loc.setLatitude(_startLat);
		loc.setLongitude(_startLong);
		loc.setTime(_time);
		loc.setSpeed(_speed);
		loc.setBearing(_direction);
		return loc;
	}
	
	public Location getEndLoc(){
		Location loc = new Location("");
		loc.setLatitude(_endLat);
		loc.setLongitude(_endLong);
		loc.setTime(_time);
		loc.setSpeed(_speed);
		loc.setBearing(_direction);
		return loc;
	}
	
	public GeoPoint getStartGeoPoint(){
		return new GeoPoint((int)(startLatitude()*1e6), (int)(startLongitude()*1e6));
	}
	
	public GeoPoint getEndGeoPoint(){
		return new GeoPoint((int)(endLatitude()*1e6), (int)(endLongitude()*1e6));
	}

	public float startLatitude(){
		return _startLat;
	}
	
	public void startLatitude(float latitude){
		_startLat = latitude;
	}
	
	public float startLongitude(){
		return _startLong;
	}
	
	public void startLongitude(float longitude){
		_startLong = longitude;
	}
	
	public float endLatitude(){
		return _endLat;
	}
	
	public void endLatitude(float latitude){
		_endLat = latitude;
	}
	
	public float endLongitude(){
		return _endLong;
	}
	
	public void endLongitude(float longitude){
		_endLong = longitude;
	}
	
	public float speed(){
		return _speed;
	}
	
	public void speed(float speed){
		_speed = speed;
	}
	
	public float direction(){
		return _direction;
	}
	
	public void direction(float direction){
		_direction = direction;
	}
	
	public String streetName(){
		return _streetName;
	}
	
	public void streetName(String streetName){
		_streetName = streetName;
	}
	
	public long time(){
		return _time;
	}
	
	public void time(long time){
		_time = time;
	}
	
	public Long id(){
		return _id;
	}
	
	public void id(Long id){
		_id = id;
	}
	
	@Override
	public String toString() {
		return "[Location s-lat:"+startLatitude()+" s-long:"+startLongitude()+"e-lat:"+endLatitude()+" e-long:"+ endLongitude()+" speed:"+speed()+" time:"+time()+ " dir:" + direction() +"]";
	}

}
